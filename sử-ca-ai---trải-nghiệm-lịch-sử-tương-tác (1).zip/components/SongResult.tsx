
import React, { useEffect, useState } from 'react';
import { Scenario } from '../types';
import { generateCertificateImage, generateHistoryAudio } from '../geminiService';

interface Props {
  userName: string;
  song: any;
  scenario: Scenario;
  status: 'SUCCESS' | 'FAILED';
  onRestart: () => void;
  finalHealth?: number;
  onGoToPhotobooth: () => void;
}

const SongResult: React.FC<Props> = ({ userName, song, scenario, status, onRestart, finalHealth = 100, onGoToPhotobooth }) => {
  const [certImage, setCertImage] = useState<string | null>(null);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const getVictoryTitle = () => {
    if (finalHealth >= 80) return "HUYỀN THOẠI BẤT TỬ";
    if (finalHealth >= 50) return "ANH HÙNG CHIẾN TRẬN";
    return "SỐNG SÓT ĐAU ĐỚN";
  };

  useEffect(() => {
    if (status === 'SUCCESS') {
      generateCertificateImage(userName, scenario.title).then(setCertImage);
      generateHistoryAudio(song.lyrics).then(setAudioBase64);
    }
  }, [status, userName, scenario.title, song.lyrics]);

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
    // Ensure buffer length is even for Int16Array
    const alignedLen = data.length - (data.length % 2);
    const dataInt16 = new Int16Array(data.buffer, 0, alignedLen / 2);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
    return buffer;
  }

  const handlePlayAudio = async () => {
    if (!audioBase64 || isPlaying) return;
    setIsPlaying(true);
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioBuffer = await decodeAudioData(decode(audioBase64), ctx, 24000, 1);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setIsPlaying(false);
      source.start();
    } catch (error) {
      console.error(error);
      setIsPlaying(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 max-w-6xl mx-auto w-full space-y-12 overflow-y-auto">
      <div className={`text-center space-y-4 ${status === 'SUCCESS' ? 'text-yellow-500' : 'text-red-600'}`}>
        <h2 className="text-5xl md:text-7xl font-cinzel font-bold uppercase tracking-tighter drop-shadow-2xl">
          {status === 'SUCCESS' ? "BẢNG VÀNG CÔNG TRẠNG" : 'DÒNG THỜI GIAN ĐỨT GÃY'}
        </h2>
        {status === 'SUCCESS' && <p className="text-white/60 font-cinzel tracking-widest uppercase">Danh hiệu: {getVictoryTitle()}</p>}
      </div>

      {status === 'SUCCESS' && (
        <div className="grid lg:grid-cols-2 gap-12 w-full animate-in zoom-in duration-1000">
          <div className="flex flex-col space-y-6">
            <div className="bg-zinc-900 p-4 rounded-3xl border-4 border-yellow-700/30 shadow-2xl relative overflow-hidden">
               <div className="absolute top-4 left-4 z-20 bg-yellow-600 text-black px-3 py-1 text-[10px] font-bold rounded">OFFICIAL CERTIFICATION</div>
               <div className="relative aspect-[16/11]">
                {certImage ? (
                  <img src={certImage} className="w-full h-full object-cover rounded-xl" alt="Certificate" />
                ) : (
                  <div className="w-full h-full bg-zinc-800 animate-pulse rounded-xl flex items-center justify-center">
                    <span className="font-cinzel text-xs text-yellow-700 uppercase">Đang khắc tên anh hùng...</span>
                  </div>
                )}
               </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => {
                const link = document.createElement('a');
                link.href = certImage || "";
                link.download = `ChungNhan_${userName}.png`;
                link.click();
              }} className="py-4 bg-yellow-600 text-white font-cinzel font-bold text-xs rounded-xl shadow-xl hover:scale-105 transition-all">
                📥 TẢI CHỨNG NHẬN
              </button>
              <button onClick={onGoToPhotobooth} className="py-4 bg-red-800 text-white font-cinzel font-bold text-xs rounded-xl shadow-xl hover:scale-105 transition-all">
                📸 CHỤP ẢNH PHOTOBOOTH
              </button>
            </div>
          </div>

          <div className="bg-zinc-950/80 backdrop-blur-xl p-10 rounded-3xl border border-white/5 flex flex-col justify-center space-y-8 shadow-2xl relative">
             <div className="text-center space-y-8 relative z-10">
                <h3 className="text-3xl font-cinzel text-white font-bold">"{song.title}"</h3>
                <div className="whitespace-pre-wrap italic text-xl font-serif text-gray-300 leading-relaxed px-4">
                  {song.lyrics}
                </div>
                {audioBase64 && (
                  <button onClick={handlePlayAudio} disabled={isPlaying} className="group flex items-center gap-4 px-8 py-4 bg-white text-black font-cinzel font-bold text-xs rounded-full hover:bg-yellow-500 transition-all mx-auto">
                    <span className="text-lg">🎧</span> {isPlaying ? 'ĐANG PHÁT...' : 'NGHE SỬ CA'}
                  </button>
                )}
             </div>
          </div>
        </div>
      )}

      {status === 'FAILED' && (
        <div className="max-w-2xl w-full text-center p-20 bg-zinc-900/50 rounded-3xl border border-red-900/20 backdrop-blur-xl space-y-12 shadow-2xl">
           <p className="text-3xl font-serif italic text-gray-300 leading-relaxed">"{song.lyrics}"</p>
           <button onClick={onRestart} className="px-16 py-5 bg-red-700 text-white font-cinzel font-bold text-xl rounded-2xl">QUAY LẠI QUÁ KHỨ</button>
        </div>
      )}

      <button onClick={onRestart} className="text-gray-600 hover:text-white font-cinzel text-[11px] uppercase tracking-[0.4em] transition-all">← VỀ TRANG CHỦ</button>
    </div>
  );
};

export default SongResult;
