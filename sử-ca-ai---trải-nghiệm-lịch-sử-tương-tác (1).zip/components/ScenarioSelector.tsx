
import React from 'react';
import { Scenario } from '../types';

interface Props {
  scenarios: Scenario[];
  onSelect: (s: Scenario) => void;
  onBack: () => void;
}

const ScenarioSelector: React.FC<Props> = ({ scenarios, onSelect, onBack }) => {
  return (
    <div className="flex-1 p-6 md:p-12 flex flex-col max-w-7xl mx-auto w-full">
      <header className="flex justify-between items-center mb-12">
        <button onClick={onBack} className="text-gray-500 hover:text-white flex items-center gap-2 group transition-colors font-cinzel text-sm">
          <span className="group-hover:-translate-x-1 transition-transform">←</span> QUAY LẠI
        </button>
        <h2 className="text-2xl font-cinzel text-yellow-500 tracking-widest uppercase">CHỌN THỜI ĐẠI XUYÊN KHÔNG</h2>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-8 animate-in fade-in slide-in-from-bottom-5 duration-700">
        {scenarios.map((s) => (
          <div 
            key={s.id}
            onClick={() => onSelect(s)}
            className="group cursor-pointer relative overflow-hidden rounded-2xl bg-zinc-950 border border-zinc-900 hover:border-yellow-600 transition-all duration-500 hover:-translate-y-2 flex flex-col shadow-2xl"
          >
            <div className="aspect-[16/10] bg-zinc-900 relative overflow-hidden">
               <img 
                src={`https://picsum.photos/seed/${s.id}/800/500`} 
                alt={s.title}
                className="w-full h-full object-cover opacity-40 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent" />
            </div>
            
            <div className="p-6 space-y-4 flex-1 flex flex-col">
              <div>
                <span className="text-[10px] font-cinzel text-yellow-700 tracking-[0.3em] uppercase">{s.era}</span>
                <h3 className="text-xl font-cinzel font-bold text-white group-hover:text-yellow-500 transition-colors mt-1">{s.title}</h3>
              </div>
              <p className="text-sm text-gray-500 line-clamp-3 leading-relaxed font-light">
                {s.description}
              </p>
              <div className="pt-4 mt-auto">
                <button className="w-full py-4 border border-yellow-700/30 text-yellow-600 font-cinzel text-xs tracking-widest group-hover:bg-yellow-700 group-hover:text-white transition-all uppercase">
                  BẮT ĐẦU CHƯƠNG NÀY
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScenarioSelector;
