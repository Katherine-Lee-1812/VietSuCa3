
import React from 'react';
import { Scenario } from '../types';

const TransitionScreen: React.FC<{ scenario: Scenario, trigger: string }> = ({ scenario, trigger }) => {
  return (
    <div className="fixed inset-0 z-[100] bg-white animate-flash flex flex-col items-center justify-center p-6 overflow-hidden">
      <div className="absolute inset-0 bg-black animate-iris-in" />
      
      <div className="relative z-10 text-center space-y-8 animate-content-reveal">
        <h2 className="text-white font-cinzel text-sm tracking-[0.5em] opacity-60">DỊCH CHUYỂN THỜI KHÔNG...</h2>
        <div className="text-6xl md:text-8xl font-cinzel font-bold text-yellow-500 drop-shadow-[0_0_30px_rgba(234,179,8,0.5)]">
          {scenario.era.split(' ')[0]}
        </div>
        <p className="text-white/40 font-cinzel tracking-widest">{scenario.title}</p>
      </div>

      <style>{`
        @keyframes flash {
          0% { opacity: 0; }
          10% { opacity: 1; }
          100% { opacity: 1; }
        }
        @keyframes iris-in {
          0% { transform: scale(0); border-radius: 100%; opacity: 1; }
          100% { transform: scale(1.5); border-radius: 0%; opacity: 1; }
        }
        @keyframes content-reveal {
          0% { opacity: 0; transform: translateY(20px); }
          50% { opacity: 0; }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-flash { animation: flash 0.5s ease-out forwards; }
        .animate-iris-in { animation: iris-in 1.5s cubic-bezier(0.7, 0, 0.3, 1) forwards; }
        .animate-content-reveal { animation: content-reveal 2.5s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default TransitionScreen;
