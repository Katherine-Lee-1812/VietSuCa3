
import React, { useState } from 'react';

interface Props {
  onStart: (name: string) => void;
}

const LandingPage: React.FC<Props> = ({ onStart }) => {
  const [name, setName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) onStart(name);
    else alert("Hãy nhập tên của bạn để bắt đầu hành trình!");
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-4xl space-y-12 animate-in fade-in duration-1000">
        <div className="space-y-4">
          <h2 className="text-yellow-600 font-cinzel text-lg tracking-[0.5em] uppercase">Vang vọng ngàn năm</h2>
          <h1 className="text-7xl md:text-9xl font-cinzel font-bold text-white drop-shadow-[0_0_20px_rgba(234,179,8,0.4)]">
            SỬ CA AI
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 max-w-sm mx-auto">
          <input 
            type="text" 
            placeholder="Nhập tên người anh hùng..." 
            className="w-full bg-white/5 border border-white/20 px-6 py-4 rounded-xl text-xl font-cinzel text-yellow-500 focus:outline-none focus:border-yellow-600 transition-all text-center"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <button 
            type="submit"
            className="group relative w-full px-10 py-5 bg-yellow-700 hover:bg-yellow-600 text-white font-cinzel font-bold text-2xl tracking-widest transition-all duration-300 rounded-xl overflow-hidden history-card-glow shadow-xl"
          >
            BẮT ĐẦU XUYÊN KHÔNG
          </button>
        </form>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12 opacity-50">
          <div className="text-sm font-cinzel tracking-wider">4 TRẬN ĐÁNH LỚN</div>
          <div className="text-sm font-cinzel tracking-wider">NHẬP VAI TƯƠNG TÁC</div>
          <div className="text-sm font-cinzel tracking-wider">BẢNG VÀNG CÔNG TRẠNG</div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
