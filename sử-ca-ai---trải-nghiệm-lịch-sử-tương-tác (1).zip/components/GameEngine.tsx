
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Scenario, UserChoice, HorrorStage, HorrorChoice } from '../types';
import { generateSceneImage, generateFinalSongLyrics, generateHorrorHint, generateHistoryAudio } from '../geminiService';
import { HO_CHI_MINH_NODES } from '../constants';

interface Props {
  scenario: Scenario;
  studentName: string;
  onFinish: (status: 'SUCCESS' | 'FAILED', songData: any, finalHealth: number) => void;
  onQuit: () => void;
}

const GameEngine: React.FC<Props> = ({ scenario, studentName, onFinish, onQuit }) => {
  const [currentStageId, setCurrentStageId] = useState<string>("start");
  const [health, setHealth] = useState(100);
  const [inventory, setInventory] = useState<string[]>([]);
  const [sceneImage, setSceneImage] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [playingVideo, setPlayingVideo] = useState(false);
  const [pendingAudio, setPendingAudio] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [explanationText, setExplanationText] = useState<string | null>(null);
  const [nextStageId, setNextStageId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [fadeStatus, setFadeStatus] = useState<'in' | 'out'>('in');
  const [hint, setHint] = useState<string | null>(null);
  const [hintLoading, setHintLoading] = useState(false);
  const [choicesMade, setChoicesMade] = useState<UserChoice[]>([]);
  
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playRawPcm = async (base64Data: string) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }

      // Convert base64 to ArrayBuffer
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Gemini TTS returns 16-bit PCM, Little Endian, 24kHz
      // Ensure buffer length is even for Int16Array
      const alignedLen = len - (len % 2);
      const int16Data = new Int16Array(bytes.buffer, 0, alignedLen / 2);
      const float32Data = new Float32Array(int16Data.length);
      for (let i = 0; i < int16Data.length; i++) {
        float32Data[i] = int16Data[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32Data.length, 24000);
      audioBuffer.getChannelData(0).set(float32Data);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.start();
    } catch (err) {
      console.error("Failed to play raw PCM audio", err);
    }
  };

  const BACH_DANG_SCRIPT: Record<string, HorrorStage> = {
    "start": {
      "text": "Bạn chớp mắt, thực tại tan biến. Hơi nước lạnh toát phả vào mặt. Bạn nhận ra mình đang đứng trên một con thuyền nan ọp ẹp, xung quanh là sương mù dày đặc che lấp cả dòng sông Bạch Đằng năm 938. Một bóng người kề gươm vào vai bạn: 'Kẻ nào dám bén mảng đến vùng cọc gỗ của Ngô Vương?'",
      "imagePrompt": "Ancient Vietnamese small boat in thick fog, dark river Bach Dang 10th century, a mysterious soldier shadow with a sword, cinematic horror atmosphere",
      "choices": [
        { "text": "Khẳng định mình là quân sư tính mực nước", "next": "encounter_soldier", "damage": 0 },
        { "text": "Cố gắng nhảy xuống sông trốn thoát", "next": "river_escape", "damage": 20, "msg": "Nước sông lạnh cóng bóp nghẹt lồng ngực bạn. Bạn bị kéo lại lên thuyền. (-20 HP)" }
      ]
    },
    "river_escape": {
      "text": "Dưới làn nước đen kịt, bạn chạm phải những đầu cọc gỗ nhọn hoắt được bọc sắt. Chúng như những chiếc răng nanh của quái thú đang chờ đợi tàu giặc. Quân lính lôi bạn lên: 'Ngu xuẩn! Ngươi muốn chết dưới bãi cọc này sao?'",
      "imagePrompt": "Under darkened river water, sharp wooden stakes with iron tips, bubbles, drowning feeling, dark horror",
      "inventoryAdd": "Mảnh gỗ bọc sắt",
      "choices": [
        { "text": "Trần tình về sự hiểu biết thủy triều", "next": "encounter_soldier", "damage": 0 }
      ]
    },
    "encounter_soldier": {
      "text": "Tên lính nhìn bạn nghi hoặc: 'Ngô Vương đang cần người biết khi nào thủy triều đạt đỉnh để nhử giặc vào lạch sâu. Ngươi có vật gì chứng minh mình là người vùng này?'",
      "imagePrompt": "Soldier with intense gaze, ancient leather armor, torch light flickering in the fog, tense visual novel style",
      "choices": [
        { "text": "Đưa 'Bản đồ da thuộc' ra", "condition": "Bản đồ da thuộc", "next": "war_room", "damage": 0 },
        { "text": "Vẽ sơ đồ bãi cọc lên mạn thuyền", "next": "war_room", "damage": 10, "msg": "Hắn tạm tin nhưng vẫn dùng dây trói tay bạn lại. (-10 HP)" }
      ]
    },
    "war_room": {
      "text": "Bạn đứng trước Ngô Quyền. Đôi mắt ông rực lửa dưới ánh đuốc: 'Tàu giặc Hoằng Tháo sắp vào cửa sông. Ta định nhử chúng vượt qua bãi cọc khi triều dâng. Ngươi nói xem, thời khắc nào là tốt nhất để phản công?'",
      "imagePrompt": "Ngo Quyen General with majestic and fierce aura, planning with maps, dark ancient room, cinematic horror lighting",
      "choices": [
        { "text": "Khi triều bắt đầu rút mạnh", "next": "victory", "damage": 0 },
        { "text": "Khi triều đang dâng cao nhất", "next": "defeat", "damage": 100, "msg": "Tàu địch lướt qua bãi cọc mà không hề hấn gì. Chúng tràn vào bờ và tàn sát toàn quân. Bạn tử trận." }
      ]
    }
  };

  const HCM_SCRIPT: Record<string, HorrorStage> = {
    "start": {
      "text": "Sau hiệp định Paris 1973, thời cơ chiến lược chín muồi, chiến dịch Hồ Chí Minh bắt đầu.",
      "imagePrompt": "Historical montage Vietnam after Paris Peace Accords 1973, US troops withdrawing, strategic military map zoom toward Saigon, cinematic documentary style",
      "videoUrl": "ban-bac",
      "choices": [
        { "text": "Tiếp tục phân tích tình hình", "next": "intro-analysis", "damage": 0 }
      ]
    },
    "intro-analysis": {
      "text": HO_CHI_MINH_NODES['intro-analysis'].narrative,
      "imagePrompt": HO_CHI_MINH_NODES['intro-analysis'].imagePrompt,
      "choices": HO_CHI_MINH_NODES['intro-analysis'].options.map(opt => ({
        text: opt.text,
        next: opt.isCorrect ? "letter-video" : "intro-analysis",
        damage: opt.damage,
        msg: opt.msg
      }))
    },
    "letter-video": {
      "text": "Gì đây, lá thư đến từ quá khứ hả?",
      "imagePrompt": "Vietnamese classroom at night, a student touching the glowing wartime letter, light expanding",
      "videoUrl": "la-thu",
      "choices": [
        { "text": "Tiếp tục", "next": "student-video", "damage": 0 }
      ]
    },
    "student-video": {
      "text": "Nếu ai đó trong tương lai đọc được những dòng này, hãy đi tiếp con đường chúng tôi đang đi.",
      "imagePrompt": "A liberation soldier in April 1975 writing a letter in a dim jungle command post, oil lamp light, distant artillery flashes",
      "videoUrl": "hoc-sinh",
      "choices": [
        { "text": "Bước vào quá khứ", "next": "letter", "damage": 0 }
      ]
    },
    "letter": {
      "text": "Bạn tỉnh dậy trong một căn hầm tối, ánh đèn dầu leo lét. Một người lính ngước lên nhìn bạn: 'Đồng chí là chiến sĩ thông tin mới? Mang điện ra mặt trận ngay! Chúng tôi đang ở rất gần Sài Gòn. Có thể đây là trận cuối cùng.'",
      "imagePrompt": "A liberation soldier in April 1975 writing a letter in a dim jungle command post, oil lamp light, distant artillery flashes, emotional cinematic realism",
      "choices": [
        { "text": "Nhận nhiệm vụ chiến sĩ thông tin", "next": "moc-1", "damage": 0 }
      ]
    },
    "moc-1": {
      "text": HO_CHI_MINH_NODES['moc-1'].narrative,
      "imagePrompt": HO_CHI_MINH_NODES['moc-1'].imagePrompt,
      "videoUrl": HO_CHI_MINH_NODES['moc-1'].videoUrl,
      "choices": HO_CHI_MINH_NODES['moc-1'].options.map(opt => ({
        text: opt.text,
        next: opt.isCorrect ? "moc-2" : "moc-1",
        damage: opt.damage,
        msg: opt.msg
      }))
    },
    "moc-2": {
      "text": HO_CHI_MINH_NODES['moc-2'].narrative,
      "imagePrompt": HO_CHI_MINH_NODES['moc-2'].imagePrompt,
      "videoUrl": HO_CHI_MINH_NODES['moc-2'].videoUrl,
      "choices": HO_CHI_MINH_NODES['moc-2'].options.map(opt => ({
        text: opt.text,
        next: opt.isCorrect ? "moc-3" : "moc-2",
        damage: opt.damage,
        msg: opt.msg
      }))
    },
    "moc-3": {
      "text": HO_CHI_MINH_NODES['moc-3'].narrative,
      "imagePrompt": HO_CHI_MINH_NODES['moc-3'].imagePrompt,
      "videoUrl": HO_CHI_MINH_NODES['moc-3'].videoUrl,
      "choices": HO_CHI_MINH_NODES['moc-3'].options.map(opt => ({
        text: opt.text,
        next: opt.isCorrect ? "moc-4" : "moc-3",
        damage: opt.damage,
        msg: opt.msg
      }))
    },
    "moc-4": {
      "text": HO_CHI_MINH_NODES['moc-4'].narrative,
      "imagePrompt": HO_CHI_MINH_NODES['moc-4'].imagePrompt,
      "videoUrl": HO_CHI_MINH_NODES['moc-4'].videoUrl,
      "choices": HO_CHI_MINH_NODES['moc-4'].options.map(opt => ({
        text: opt.text,
        next: opt.isCorrect ? "final-classroom" : "moc-4",
        damage: opt.damage,
        msg: opt.msg
      }))
    },
    "final-classroom": {
      "text": "Sài Gòn – 30/4/1975. Chúng tôi đã hoàn thành. Chiến dịch Hồ Chí Minh toàn thắng.",
      "imagePrompt": "Vietnamese classroom, bright sunlight, students looking at a historical document with respect, peaceful atmosphere",
      "videoUrl": "4",
      "choices": [
        { "text": "Kết thúc hành trình", "next": "victory", "damage": 0 }
      ]
    }
  };

  const STEM_SCRIPT: Record<string, HorrorStage> = {
    "start": {
      "text": "Dịch bệnh Corona đang bùng phát. Nhu cầu về nước rửa tay sát khuẩn trở nên khan hiếm. Bạn là một học sinh lớp 11, hãy vận dụng kiến thức Hóa học để giúp cộng đồng.",
      "imagePrompt": "Empty streets during lockdown, news reports about virus, high school student looking at chemistry books",
      "choices": [
        { "text": "Bắt đầu nghiên cứu công thức WHO", "next": "formula-selection", "damage": 0 }
      ]
    },
    "formula-selection": {
      "text": "Theo WHO, có 2 công thức chính để pha chế nước rửa tay. Công thức 1 sử dụng Ethanol 96%. Bạn cần chuẩn bị những gì?",
      "imagePrompt": "Chemistry lab equipment, bottles of ethanol, glycerol, and hydrogen peroxide on a table",
      "choices": [
        { "text": "Ethanol, Glycerol, H2O2, Nước cất", "next": "mixing-process", "damage": 0 },
        { "text": "Ethanol, Xà phòng, Nước máy", "next": "formula-selection", "damage": 10, "msg": "Sai rồi! Xà phòng không dùng trong công thức nước rửa tay khô của WHO." }
      ]
    },
    "mixing-process": {
      "text": "Bạn bắt đầu pha chế. Thứ tự cho các chất vào bình là rất quan trọng để đảm bảo an toàn và nồng độ. Bạn sẽ cho chất nào vào cuối cùng?",
      "imagePrompt": "Student carefully pouring liquid into a measuring cylinder, wearing gloves and goggles",
      "choices": [
        { "text": "Nước cất (để định mức)", "next": "quality-check", "damage": 0 },
        { "text": "Ethanol 96%", "next": "mixing-process", "damage": 15, "msg": "Nguy hiểm! Cồn nồng độ cao nên được cho vào trước để hòa tan các chất khác." }
      ]
    },
    "quality-check": {
      "text": "Sản phẩm đã hoàn thành. Để tăng tính sát khuẩn và tạo mùi thơm dễ chịu, bạn có thể thêm tinh dầu thảo mộc. Bạn chọn loại nào?",
      "imagePrompt": "Small bottles of essential oils (cinnamon, lemongrass), finished hand sanitizer bottles",
      "choices": [
        { "text": "Tinh dầu sả hoặc quế", "next": "victory", "damage": 0 },
        { "text": "Dầu ăn", "next": "quality-check", "damage": 20, "msg": "Dầu ăn sẽ làm hỏng dung dịch và không có tính sát khuẩn!" }
      ]
    }
  };

  const DYNAMIC_SCRIPT = scenario.id === 'ho-chi-minh-1975' ? HCM_SCRIPT : 
                        scenario.id === 'stem-sanitizer' ? STEM_SCRIPT : 
                        BACH_DANG_SCRIPT;

  useEffect(() => {
    if (!playingVideo && pendingAudio) {
      playRawPcm(pendingAudio);
      setPendingAudio(null);
    }
  }, [playingVideo, pendingAudio]);

  const playSoundEffect = (type: 'scream' | 'heartbeat') => {
    if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    if (type === 'scream') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(60, ctx.currentTime);
      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
    }
    
    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  };

  const loadStage = async (stageId: string) => {
    setFadeStatus('out');
    setLoading(true);
    setHint(null);
    setShowExplanation(false);
    setExplanationText(null);
    setNextStageId(null);
    
    await new Promise(r => setTimeout(r, 800));

    const stage = DYNAMIC_SCRIPT[stageId] || DYNAMIC_SCRIPT["start"];
    if (stage.inventoryAdd && !inventory.includes(stage.inventoryAdd)) {
      setInventory(prev => [...prev, stage.inventoryAdd!]);
    }

    if (stage.videoUrl) {
      setVideoUrl(stage.videoUrl);
      setPlayingVideo(true);
    } else {
      setVideoUrl(null);
      setPlayingVideo(false);
    }

    try {
      const img = await generateSceneImage(stage.imagePrompt);
      setSceneImage(img);
      
      // Prepare audio for intro if it's Ho Chi Minh campaign
      if (scenario.id === 'ho-chi-minh-1975') {
        const audioBase64 = await generateHistoryAudio(stage.text);
        if (audioBase64 && audioBase64.length > 0) {
          if (stage.videoUrl) {
            setPendingAudio(audioBase64);
          } else {
            playRawPcm(audioBase64);
          }
        }
      }
    } catch (err) { console.error(err); }
    
    setLoading(false);
    setFadeStatus('in');
  };

  useEffect(() => {
    loadStage(currentStageId);
  }, [currentStageId]);

  const handleChoice = async (choice: HorrorChoice) => {
    if (choice.condition && !inventory.includes(choice.condition)) {
      alert(`Bạn cần có [${choice.condition}] để thực hiện lựa chọn này!`);
      return;
    }

    if (choice.damage > 0) {
      playSoundEffect('scream');
      playSoundEffect('heartbeat');
    }

    const newHealth = Math.max(0, health - choice.damage);
    setHealth(newHealth);
    
    const stage = DYNAMIC_SCRIPT[currentStageId] || DYNAMIC_SCRIPT["start"];
    if (stage.inventoryAdd && !inventory.includes(stage.inventoryAdd)) {
      setInventory(prev => [...prev, stage.inventoryAdd!]);
    }

    setChoicesMade(prev => [...prev, {
      nodeId: currentStageId,
      choiceText: choice.text,
      isCorrect: choice.damage === 0,
      damageTaken: choice.damage
    }]);

    if (choice.msg) {
      setExplanationText(choice.msg);
      setShowExplanation(true);
      setNextStageId(choice.next);
      playSoundEffect('heartbeat');
      if (choice.damage > 0) playSoundEffect('scream');
      return; // Stop here to show explanation
    }

    proceedToNext(choice.next, newHealth);
  };

  const proceedToNext = async (nextId: string, currentHealth: number) => {
    if (nextId === "victory") {
      setLoading(true);
      let finalPrompt = scenario.title;
      if (scenario.id === 'ho-chi-minh-1975') {
        finalPrompt += ". Yêu cầu: Kết thúc bài thơ bằng dòng chữ 'Sài Gòn – 30/4/1975. Chúng tôi đã hoàn thành.'";
      }
      const song = await generateFinalSongLyrics(finalPrompt, choicesMade.map(c => c.choiceText));
      onFinish('SUCCESS', song, currentHealth);
    } else if (nextId === "defeat") {
      onFinish('FAILED', { lyrics: "Lịch sử đã bị thiêu rụi. Bạn tử trận giữa dòng nước xiết.", title: "Bi Kịch Bạch Đằng" }, 0);
    } else {
      setCurrentStageId(nextId);
    }
  };

  const showHint = async () => {
    setHintLoading(true);
    try {
      const h = await generateHorrorHint(scenario.title, DYNAMIC_SCRIPT[currentStageId].text);
      setHint(h);
    } catch (e) {
      setHint("Quá khứ đang gào thét... hãy chọn con đường của nước.");
    } finally {
      setHintLoading(false);
    }
  };

  if (health <= 0) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center p-10 z-[200]">
        <h1 className="glitch font-horror text-8xl mb-8" data-text="KẾT THÚC">KẾT THÚC</h1>
        <p className="font-cinzel text-red-600 mb-12 text-center">Bóng tối đã nuốt chửng bạn. Lịch sử bị lãng quên vì sai lầm của kẻ xuyên không...</p>
        <button onClick={onQuit} className="px-12 py-4 border-2 border-red-600 text-red-600 font-cinzel hover:bg-red-600 hover:text-white transition-all uppercase tracking-widest">Quay lại thực tại</button>
      </div>
    );
  }

  const stage = DYNAMIC_SCRIPT[currentStageId] || DYNAMIC_SCRIPT["start"];

  return (
    <div className={`flex-1 flex flex-col h-screen overflow-hidden bg-black transition-opacity duration-1000 ${fadeStatus === 'in' ? 'opacity-100' : 'opacity-0'}`}>
      <div className="absolute top-6 left-6 z-50 flex items-start gap-6">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3 bg-black/80 p-2 rounded-lg border border-red-900 shadow-[0_0_15px_rgba(153,27,27,0.3)]">
            <span className="text-red-600 text-xs font-horror tracking-widest">SINH LỰC</span>
            <div className="w-48 h-3 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
              <div className="h-full bg-gradient-to-r from-red-900 to-red-500 transition-all duration-700" style={{ width: `${health}%` }} />
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 bg-black/80 p-2 rounded-lg border border-zinc-800 shadow-xl group">
          <div className="text-xl">🎒</div>
          <div className="flex gap-2">
            {inventory.length === 0 ? (
              <span className="text-[10px] text-zinc-600 font-cinzel italic">Túi đồ trống...</span>
            ) : (
              inventory.map((item, idx) => (
                <div key={idx} className="inventory-item px-2 py-1 bg-zinc-900 border border-zinc-700 rounded text-[9px] text-zinc-400 font-cinzel">
                  {item}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="h-[70vh] relative overflow-hidden">
        {playingVideo && videoUrl ? (
          <div className="absolute inset-0 bg-black z-50">
            <video 
              src={`/videos/${videoUrl}.mp4`} 
              autoPlay 
              onEnded={() => setPlayingVideo(false)}
              onError={(e) => {
                console.warn(`Video ${videoUrl} failed to load, skipping...`, e);
                setPlayingVideo(false);
              }}
              className="w-full h-full object-contain"
            />
            <button 
              onClick={() => setPlayingVideo(false)}
              className="absolute bottom-6 right-6 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-[10px] font-cinzel rounded-full border border-white/20 backdrop-blur-md transition-all"
            >
              BỎ QUA VIDEO
            </button>
          </div>
        ) : loading ? (
          <div className="absolute inset-0 flex items-center justify-center bg-black">
            <div className="w-16 h-16 border-4 border-zinc-900 border-t-red-600 rounded-full animate-spin" />
          </div>
        ) : (
          <img src={sceneImage || ""} className="w-full h-full object-cover animate-pulse-subtle" alt="Scene" />
        )}
      </div>

      <div className="h-[30vh] horror-box p-8 flex flex-col relative z-40">
        <button onClick={showHint} className="absolute -top-14 right-10 w-14 h-14 bg-black border-2 border-red-900 rounded-full flex items-center justify-center hover:scale-110 transition-transform">
          <span className={`text-2xl ${hintLoading ? 'animate-spin' : ''}`}>👁️</span>
        </button>
        {hint && (
          <div className="absolute -top-28 left-1/2 -translate-x-1/2 w-2/3 bg-black/95 border border-red-900/50 p-4 rounded-xl text-xs italic text-red-200 font-cinzel">
            <span className="text-red-600 block mb-1 font-bold">LỜI THÌ THẦM:</span> "{hint}"
          </div>
        )}
        
        {showExplanation && explanationText ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex-1 flex flex-col items-center justify-center text-center space-y-4"
          >
            <h3 className="text-red-500 font-cinzel text-sm tracking-[0.3em] uppercase">Phân tích chiến lược</h3>
            <p className="text-zinc-100 font-cinzel italic text-lg max-w-2xl">
              "{explanationText}"
            </p>
            <button
              onClick={() => proceedToNext(nextStageId!, health)}
              className="px-8 py-2 bg-red-900/40 hover:bg-red-900/60 border border-red-500/50 text-white font-cinzel text-xs tracking-widest rounded-full transition-all"
            >
              TIẾP TỤC
            </button>
          </motion.div>
        ) : (
          <div className="flex-1 flex flex-col md:flex-row gap-10 overflow-hidden">
            <div className="flex-1 overflow-y-auto pr-6 custom-scroll">
               <p className="text-xl md:text-2xl font-light italic text-zinc-200 leading-relaxed font-serif">
                 {stage.text}
               </p>
            </div>
            <div className="flex flex-col gap-4 min-w-[320px]">
               {stage.choices.map((choice, idx) => (
                 <button
                  key={idx}
                  disabled={choice.condition ? !inventory.includes(choice.condition) : false || playingVideo}
                  onClick={() => handleChoice(choice)}
                  className={`w-full p-5 bg-zinc-900/60 border border-zinc-800 hover:border-red-600 hover:bg-red-950/20 text-left transition-all rounded-xl font-cinzel text-sm group flex items-start gap-3 ${choice.condition && !inventory.includes(choice.condition) ? 'opacity-30' : ''}`}
                 >
                   <span className="text-red-700 mt-1">▶</span>
                   <div>
                     <span className="block">{choice.text}</span>
                     {choice.condition && !inventory.includes(choice.condition) && (
                       <span className="text-[9px] text-zinc-500 mt-1 block uppercase">(CẦN: {choice.condition})</span>
                     )}
                   </div>
                 </button>
               ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameEngine;
