
import React, { useRef, useState, useEffect } from 'react';
import { Scenario } from '../types';

interface Props {
  scenario: Scenario;
  userName: string;
  onBack: () => void;
}

const BACH_DANG_FRAME_URL = "https://i.ibb.co/v4m0LzZ/bach-dang-frame.png"; // Đảm bảo URL này hoạt động

const Photobooth: React.FC<Props> = ({ scenario, userName, onBack }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [frameImage, setFrameImage] = useState<HTMLImageElement | null>(null);
  const [isLoadingFrame, setIsLoadingFrame] = useState(false);

  // Kiểm tra kịch bản Bạch Đằng dựa trên ID chính xác
  const isBachDang = scenario.id === 'bach-dang-938';

  useEffect(() => {
    let stream: MediaStream | null = null;
    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'user', 
            width: { ideal: 1280 }, 
            height: { ideal: 720 } 
          } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setIsCameraReady(true);
        }
      } catch (err) {
        console.error("Camera error:", err);
        alert("Không thể truy cập camera. Vui lòng kiểm tra quyền truy cập.");
      }
    };

    if (isBachDang) {
      setIsLoadingFrame(true);
      const img = new Image();
      img.crossOrigin = "anonymous"; // Thiết lập TRƯỚC khi gán src
      img.onload = () => {
        console.log("Bach Dang frame loaded successfully");
        setFrameImage(img);
        setIsLoadingFrame(false);
      };
      img.onerror = (e) => {
        console.error("Could not load Bach Dang frame", e);
        setIsLoadingFrame(false);
      };
      img.src = BACH_DANG_FRAME_URL;
    }

    startCamera();
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [isBachDang]);

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const context = canvasRef.current.getContext('2d');
    if (!context) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (isBachDang && frameImage) {
      // Tỉ lệ khung hình gốc là khoảng 3:2 (1500x1000)
      canvas.width = frameImage.width;
      canvas.height = frameImage.height;

      // 1. Vẽ khung hình nền (Cuốn sách + Ngô Quyền)
      context.drawImage(frameImage, 0, 0);

      // 2. Tọa độ ô trống trên trang sách bên phải (Dựa trên ảnh bạn gửi)
      // X: Bắt đầu từ khoảng 47.8% chiều rộng
      // Y: Bắt đầu từ khoảng 15.5% chiều cao
      // Width: Khoảng 23.2% chiều rộng
      // Height: Khoảng 55.5% chiều cao
      const photoArea = {
        x: canvas.width * 0.478,
        y: canvas.height * 0.155,
        width: canvas.width * 0.232,
        height: canvas.height * 0.555
      };

      // 3. Cắt và vẽ video vào ô trống
      const videoAspect = video.videoWidth / video.videoHeight;
      const targetAspect = photoArea.width / photoArea.height;

      let sourceX = 0, sourceY = 0, sourceWidth = video.videoWidth, sourceHeight = video.videoHeight;

      if (videoAspect > targetAspect) {
        sourceWidth = video.videoHeight * targetAspect;
        sourceX = (video.videoWidth - sourceWidth) / 2;
      } else {
        sourceHeight = video.videoWidth / targetAspect;
        sourceY = (video.videoHeight - sourceHeight) / 2;
      }

      context.drawImage(
        video,
        sourceX, sourceY, sourceWidth, sourceHeight,
        photoArea.x, photoArea.y, photoArea.width, photoArea.height
      );

      // 4. Hiệu ứng làm cũ ảnh (Sepia/Overlay)
      context.fillStyle = "rgba(139, 69, 19, 0.15)"; 
      context.fillRect(photoArea.x, photoArea.y, photoArea.width, photoArea.height);
      
      // Vẽ thêm một lớp viền mờ bên trong để ảnh trông tự nhiên hơn trong trang sách
      context.strokeStyle = "rgba(0,0,0,0.2)";
      context.lineWidth = 2;
      context.strokeRect(photoArea.x, photoArea.y, photoArea.width, photoArea.height);

    } else {
      // Khung mặc định cho các kịch bản khác
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0);

      context.strokeStyle = "#eab308";
      context.lineWidth = 20;
      context.strokeRect(0, 0, canvas.width, canvas.height);

      context.fillStyle = "rgba(0,0,0,0.5)";
      context.fillRect(0, canvas.height - 100, canvas.width, 100);

      context.fillStyle = "white";
      context.font = "bold 30px Cinzel, serif";
      context.fillText(`${userName} cùng anh hùng tại ${scenario.title}`, 40, canvas.height - 40);
    }

    setCapturedImage(canvas.toDataURL('image/png'));
  };

  const getCharacterLabel = () => {
    if (scenario.id.includes('bach-dang')) return "Ngô Quyền";
    if (scenario.id.includes('dien-bien')) return "Võ Nguyên Giáp";
    if (scenario.id.includes('lam-son')) return "Lê Lợi";
    return "Chiến sĩ Cách mạng";
  };

  return (
    <div className="fixed inset-0 bg-black z-[150] flex flex-col items-center justify-center p-6 space-y-8 overflow-hidden">
      <div className="absolute top-6 left-6 z-20">
        <button onClick={onBack} className="text-white font-cinzel text-sm border-b border-white hover:text-red-500 transition-colors uppercase">← QUAY LẠI</button>
      </div>

      <h2 className="text-3xl font-cinzel text-yellow-500 tracking-widest uppercase">PHOTOBOOTH LỊCH SỬ</h2>

      <div className="relative w-full max-w-4xl aspect-video bg-zinc-900 rounded-3xl overflow-hidden border-4 border-yellow-700/30 shadow-2xl">
        {isLoadingFrame && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-50">
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-yellow-600 border-t-transparent rounded-full animate-spin"></div>
              <p className="font-cinzel text-yellow-500 animate-pulse">ĐANG TẢI KHUNG HÌNH LỊCH SỬ...</p>
            </div>
          </div>
        )}

        {!capturedImage ? (
          <>
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover grayscale brightness-75" />
            
            {isBachDang && frameImage ? (
              <div className="absolute inset-0 pointer-events-none">
                <img src={frameImage.src} className="w-full h-full object-contain" alt="Frame Overlay" />
                <div className="absolute top-[15%] left-[47.8%] w-[23.2%] h-[55.5%] border-2 border-dashed border-yellow-500/30 flex items-center justify-center">
                  <p className="text-[8px] text-yellow-500/50 font-cinzel text-center px-2">CĂN CHỈNH TẠI ĐÂY</p>
                </div>
              </div>
            ) : (
              <>
                <div className="absolute inset-0 border-[20px] border-yellow-600/20 pointer-events-none" />
                <div className="absolute bottom-6 right-6 bg-yellow-600 text-black px-4 py-2 font-cinzel font-bold text-xs rounded-full">
                  ĐANG CÙNG: {getCharacterLabel().toUpperCase()}
                </div>
                {/* Visual simulation of historical character frame overlay */}
                <div className="absolute top-0 right-0 h-full w-1/3 opacity-40 pointer-events-none bg-gradient-to-l from-yellow-900/40 to-transparent flex items-end p-8">
                   <div className="text-[80px] grayscale opacity-20">🐉</div>
                </div>
              </>
            )}
          </>
        ) : (
          <img src={capturedImage} className="w-full h-full object-contain bg-black" alt="Captured" />
        )}
      </div>

      <div className="flex gap-4">
        {!capturedImage ? (
          <button 
            onClick={takePhoto}
            disabled={!isCameraReady}
            className="px-12 py-5 bg-yellow-600 text-white font-cinzel font-bold text-xl rounded-2xl hover:bg-yellow-500 transition-all shadow-xl disabled:opacity-50"
          >
            📸 CHỤP ẢNH NGAY
          </button>
        ) : (
          <>
            <button 
              onClick={() => setCapturedImage(null)}
              className="px-10 py-4 bg-zinc-800 text-white font-cinzel font-bold text-sm rounded-xl hover:bg-zinc-700 transition-all"
            >
              🔄 CHỤP LẠI
            </button>
            <button 
              onClick={() => {
                const link = document.createElement('a');
                link.href = capturedImage || "";
                link.download = `PhotoBooth_${userName}.png`;
                link.click();
              }}
              className="px-10 py-4 bg-red-800 text-white font-cinzel font-bold text-sm rounded-xl hover:bg-red-700 transition-all"
            >
              📥 LƯU ẢNH
            </button>
          </>
        )}
      </div>

      <canvas ref={canvasRef} className="hidden" />
      
      <div className="max-w-md text-center">
        <p className="text-zinc-500 font-cinzel text-[10px] tracking-widest leading-relaxed">
          GHI CHÚ: Ảnh của bạn được ghép cùng linh hồn của các anh hùng dân tộc trong khung hình Sắc Phong cổ điển.
        </p>
      </div>
    </div>
  );
};

export default Photobooth;
