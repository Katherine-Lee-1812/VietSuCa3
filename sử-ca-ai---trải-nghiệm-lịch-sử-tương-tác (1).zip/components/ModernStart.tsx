
import React, { useEffect, useState } from 'react';
import { generateModernStart } from '../geminiService';
import { Scenario } from '../types';

interface Props {
  targetScenario: Scenario;
  onTravel: (sit: string, trigger: string) => void;
  onBack: () => void;
}

const ModernStart: React.FC<Props> = ({ targetScenario, onTravel, onBack }) => {
  const [data, setData] = useState<{situation: string, trigger: string} | null>(null);
  const [loading, setLoading] = useState(true);

  const loadSituation = async () => {
    setLoading(true);
    try {
      const result = await generateModernStart(targetScenario.id);
      setData({
        situation: result.situation,
        trigger: result.transitionTrigger
      });
    } catch (e) {
      setData({
        situation: "Một luồng sáng lạnh toát bao trùm căn phòng. Kim đồng hồ bắt đầu quay ngược với tốc độ chóng mặt...",
        trigger: "CHẠM VÀO KHOẢNG KHÔNG"
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    loadSituation();
  }, [targetScenario]);

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-6">
        <div className="w-12 h-12 border-2 border-yellow-600 border-t-transparent rounded-full animate-spin" />
        <p className="font-cinzel text-yellow-500 animate-pulse uppercase tracking-[0.3em] text-xs">Đang xâu chuỗi thực tại...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 animate-in fade-in slide-in-from-bottom-10 duration-1000">
      <div className="max-w-2xl w-full bg-zinc-950 border border-white/5 p-8 md:p-12 rounded-3xl backdrop-blur-xl relative overflow-hidden shadow-[0_0_50px_rgba(0,0,0,1)]">
        <div className="absolute top-0 right-0 p-6">
           <button onClick={onBack} className="text-zinc-700 hover:text-white transition-colors text-xl">✕</button>
        </div>
        
        <div className="mb-10">
           <span className="text-red-900 font-cinzel text-[10px] tracking-[0.5em] uppercase font-bold">DẤU HIỆU CỦA SỰ BẤT THƯỜNG</span>
           <h2 className="text-white font-cinzel text-2xl mt-3 tracking-tighter">Biến cố tại: {targetScenario.title}</h2>
        </div>
        
        <div className="space-y-12">
          <p className="text-2xl md:text-3xl font-serif italic text-gray-300 leading-relaxed drop-shadow-lg">
            "{data?.situation}"
          </p>
          
          <div className="pt-4">
            <button 
              onClick={() => onTravel(data!.situation, data!.trigger)}
              className="group relative w-full py-7 bg-red-900 text-white font-cinzel font-bold text-xl hover:bg-red-800 transition-all duration-500 rounded-2xl overflow-hidden shadow-2xl tracking-[0.2em]"
            >
              <span className="relative z-10 uppercase">{data?.trigger}</span>
              <div className="absolute inset-0 bg-red-600 translate-x-full group-hover:translate-x-0 transition-transform duration-500 opacity-20" />
            </button>
            <p className="mt-8 text-center text-[9px] text-zinc-600 font-cinzel tracking-[0.4em] animate-pulse uppercase">Nhấn để phá vỡ kết cấu không gian</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernStart;
