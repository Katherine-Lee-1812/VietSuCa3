
import { Scenario, HistoryNode } from './types';

export const SCENARIOS: Scenario[] = [
  {
    id: 'bach-dang-938',
    title: 'Hào Khí Bạch Đằng',
    era: 'Năm 938 - Ngô Quyền',
    description: 'Vào vai phó tướng giúp Ngô Quyền tính toán thủy triều và vị trí đóng cọc gỗ.',
    imagePrompt: 'General Ngo Quyen standing on a traditional Vietnamese war junk, river Bach Dang, giant wooden stakes, dawn light, 10th century',
    facts: ['Ngô Quyền', 'Kiều Công Tiễn', 'Hoằng Tháo', 'Thủy triều', 'Cọc gỗ bọc sắt']
  },
  {
    id: 'dien-bien-phu-1954',
    title: 'Điện Biên Phủ: Thiên Sử Vàng',
    era: 'Năm 1954 - Võ Nguyên Giáp',
    description: 'Tham gia vào bộ phận hậu cần và kéo pháo, đưa ra quyết định thay đổi phương châm tác chiến.',
    imagePrompt: 'Vietnamese soldiers pulling artillery through muddy mountains, jungles of Dien Bien, night with torches, 1950s',
    facts: ['Đại tướng Võ Nguyên Giáp', 'Kéo pháo vào kéo pháo ra', 'Đánh chắc tiến chắc', 'Hầm De Castries']
  },
  {
    id: 'lam-son-1418',
    title: 'Bình Ngô Đại Cáo',
    era: 'Năm 1418 - Lê Lợi',
    description: 'Trở thành cận vệ thân tín của Lê Lợi, bảo vệ chủ tướng trong những ngày gian khổ tại núi Chí Linh.',
    imagePrompt: 'Le Loi in traditional royal armor, misty Lam Son mountains, secret strategy meeting, 15th century forest',
    facts: ['Lê Lợi', 'Nguyễn Trãi', 'Lê Lai cứu chúa', 'Hội thề Lũng Nhai']
  },
  {
    id: 'ho-chi-minh-1975',
    title: 'Theo Dấu Chiến Dịch Hồ Chí Minh',
    era: 'Tháng 4/1975',
    description: 'Vào vai chiến sĩ thông tin, ghi nhận những khoảnh khắc thần tốc giải phóng miền Nam, thống nhất đất nước.',
    imagePrompt: 'Historical montage Vietnam after Paris Peace Accords 1973, US troops withdrawing, strategic military map zoom toward Saigon, cinematic documentary style',
    facts: ['Chiến dịch Hồ Chí Minh', '26/4/1975', 'Không kích Tân Sơn Nhất', 'Xe tăng 390', 'Dinh Độc Lập']
  },
  {
    id: 'stem-sanitizer',
    title: 'STEM: Chế tạo nước rửa tay',
    era: 'Thời đại COVID-19',
    description: 'Ứng dụng kiến thức Hóa học hữu cơ lớp 11 để pha chế dung dịch sát khuẩn theo tiêu chuẩn WHO.',
    imagePrompt: 'High school students in a chemistry lab, wearing masks and lab coats, mixing ethanol and glycerol, scientific atmosphere',
    facts: ['Ethanol 96%', 'Glycerol', 'Hydrogen Peroxide', 'Tinh dầu sả/quế', 'Tiêu chuẩn WHO']
  }
];

export const HO_CHI_MINH_NODES: Record<string, HistoryNode & { videoUrl?: string }> = {
  'intro-analysis': {
    narrative: "DỮ KIỆN CHIẾN TRƯỜNG:\n• Mĩ đã rút quân\n• Quân Sài Gòn rút chạy chiến lược ở miền Trung\n• Ta giải phóng vùng rộng lớn trong thời gian rất ngắn\n\nNHẬN ĐỊNH: Nhận định nào giải thích đúng nhất quyết định giải phóng miền Nam trong năm 1975?",
    imagePrompt: "1975 war briefing screen with historical documents, typewriter text, glowing highlighted key facts, grunge military UI style",
    videoUrl: "ban-bac",
    options: [
      { text: "Ta mạnh lên về quân số đơn thuần", isCorrect: false, damage: 20, msg: "Chưa chính xác. Quân số chỉ là một phần, yếu tố thời cơ mới là quyết định." },
      { text: "Hệ thống phòng thủ chiến lược của đối phương đã bị phá vỡ, tạo ra thời cơ quyết định", isCorrect: true, damage: 0, msg: "Chính xác! Cấu trúc phòng thủ sụp đổ tạo ra thời cơ 'một ngày bằng hai mươi năm'." },
      { text: "Chiến tranh đã kéo dài quá lâu", isCorrect: false, damage: 10, msg: "Đây là lý do mong muốn, nhưng không phải căn cứ quân sự để mở chiến dịch." }
    ]
  },
  'moc-1': {
    narrative: "26/4/1975: NỔ SÚNG. Các quân đoàn đã vào vị trí. Lệnh: nổ súng cùng giờ trên toàn mặt trận.\n\nCÂU HỎI: Việc nổ súng cùng thời điểm nhằm đạt hiệu quả nào ở cấp chiến dịch?",
    imagePrompt: "Massive coordinated artillery strike at night April 26 1975 around Saigon, tanks starting engines, soldiers advancing in darkness",
    videoUrl: "1",
    options: [
      { text: "Tăng hỏa lực trên một hướng", isCorrect: false, damage: 15, msg: "Sai. Nổ súng toàn mặt trận là để phân tán hỏa lực địch, không phải tập trung vào một điểm." },
      { text: "Làm tê liệt khả năng điều quân cơ động giữa các tuyến phòng thủ", isCorrect: true, damage: 0, msg: "Đúng! Đánh đồng loạt khiến địch không thể ứng cứu cho nhau." },
      { text: "Tạo yếu tố bất ngờ về thời gian", isCorrect: false, damage: 10, msg: "Bất ngờ là một phần, nhưng mục tiêu chính là phá vỡ hệ thống hiệp đồng của địch." }
    ]
  },
  'moc-2': {
    narrative: "28/4: KHÔNG KÍCH TÂN SƠN NHẤT. Phi đội Quyết Thắng sử dụng máy bay A37 thu được của địch để ném bom sân bay.\n\nCÂU HỎI: Điểm độc đáo khiến trận đánh này có tác động lớn hơn thiệt hại vật chất là gì?",
    imagePrompt: "Captured A37 aircraft bombing Tan Son Nhat airbase April 28 1975, runway explosions, shocked defending forces",
    videoUrl: "2",
    options: [
      { text: "Ta sử dụng loại máy bay hiện đại", isCorrect: false, damage: 10, msg: "A37 không phải là máy bay hiện đại nhất lúc đó." },
      { text: "Đối phương bị đánh bởi chính loại máy bay họ từng sử dụng", isCorrect: true, damage: 0, msg: "Chính xác! Cú sốc tâm lý khiến địch hoang mang tột độ: 'Gậy ông đập lưng ông'." },
      { text: "Số lượng bom lớn", isCorrect: false, damage: 15, msg: "Số lượng bom không phải là yếu tố gây bất ngờ nhất trong trận này." }
    ]
  },
  'moc-3': {
    narrative: "THẦN TỐC. Các cánh quân tiến như vũ bão, 'Thần tốc, thần tốc hơn nữa'.\n\nCÂU HỎI: Trong điều kiện hành quân liên tục, yếu tố nào giúp chiến dịch vẫn giữ được sức tiến công?",
    imagePrompt: "Liberation army mechanized columns moving day and night toward Saigon, soldiers resting on moving trucks",
    videoUrl: "3",
    options: [
      { text: "Hậu cần từ miền Bắc chuyển vào kịp thời", isCorrect: false, damage: 15, msg: "Miền Bắc quá xa để tiếp tế tức thời cho tốc độ thần tốc này." },
      { text: "Kết hợp hậu cần chuẩn bị trước với khai thác tại chỗ khi tiến công", isCorrect: true, damage: 0, msg: "Đúng! Hậu cần cũng phải 'thần tốc' và linh hoạt như mũi tiến công." },
      { text: "Giảm nhịp độ tiến quân", isCorrect: false, damage: 20, msg: "Sai hoàn toàn. Giảm nhịp độ sẽ làm mất thời cơ chiến lược." }
    ]
  },
  'moc-4': {
    narrative: "DINH ĐỘC LẬP. Xe tăng 390 húc đổ cổng dinh. Tổng thống Dương Văn Minh tuyên bố đầu hàng.\n\nCÂU HỎI: Sự kiện này kết thúc chiến tranh vì:",
    imagePrompt: "Tank 390 entering Independence Palace, soldiers raising liberation flag, bright noon sunlight April 30 1975",
    videoUrl: "4",
    options: [
      { text: "Ta chiếm được mục tiêu quan trọng", isCorrect: false, damage: 10, msg: "Chiếm mục tiêu chỉ là về mặt quân sự, ý nghĩa chính trị còn lớn hơn." },
      { text: "Bộ máy chính quyền trung ương chấm dứt tồn tại", isCorrect: true, damage: 0, msg: "Đúng! Đây là dấu chấm hết cho chế độ cũ, đất nước hoàn toàn thống nhất." },
      { text: "Địch hết khả năng chiến đấu tại chỗ", isCorrect: false, damage: 15, msg: "Nhiều nơi địch vẫn còn quân nhưng không còn ý nghĩa khi chính phủ đã đầu hàng." }
    ]
  }
};

export const MODERN_SITUATIONS = [
  "Chiếc gương nứt: Bạn đứng soi gương trong nhà vệ sinh, hình ảnh phản chiếu bỗng dưng chậm lại 1 giây. Bạn chạm vào vết nứt và bị hút đi...",
  "Tiếng ve kêu giữa mùa đông: Bạn nghe tiếng ve râm ran dù trời đang lạnh buốt. Mở cửa sổ ra, bạn thấy mình đứng trên đỉnh đèo giữa rừng sâu...",
  "Bản nhạc ngược: Bạn vô tình phát ngược một bài hát cũ. Không gian quay cuồng, bạn tỉnh dậy trên một con thuyền chiến cổ xưa...",
  "Hố đen dưới gầm giường: Bạn cúi xuống nhặt bút, nhưng thay vì sàn nhà, bạn chạm phải một mặt nước lạnh toát và rơi xuống...",
  "Cuộc gọi từ quá khứ: Điện thoại hiện số lạ '0000'. Nghe máy chỉ thấy tiếng súng nổ, rồi một luồng điện đưa bạn đi thẳng về quá khứ...",
  "Mùi trầm hương lạ: Khói trắng bao phủ phòng bạn, khi khói tan, bạn thấy mình đang đứng giữa một bàn tiệc cung đình đầy nến...",
  "Thang máy số 0: Thang máy hiện số tầng là '0'. Cửa mở ra một cánh đồng hoang vu đầy quân sĩ đang đóng cọc gỗ...",
  "Tranh sơn dầu cử động: Bạn nhìn vào bức tranh trận đánh trong bảo tàng. Các nhân vật bỗng kéo tay bạn vào trong vùng khói lửa...",
  "Đồng hồ cát chảy ngược: Cát chảy ngược lên trên, thời gian lùi lại nhanh chóng cho đến khi bạn đứng trước một vị tướng quân...",
  "Tiếng bước chân lạ: Bạn nghe tiếng bước chân kim loại phía sau. Quay lại, đó là một vị tướng giáp sắt đang chỉ tay về phía cổng ánh sáng...",
  // AI sẽ ngẫu nhiên hóa các biến thể khác dựa trên danh sách này
];
