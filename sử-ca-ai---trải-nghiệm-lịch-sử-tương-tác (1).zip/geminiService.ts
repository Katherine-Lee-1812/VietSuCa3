
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { HistoryNode, Scenario } from "./types";

export const getGeminiClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateHorrorHint = async (scenarioTitle: string, currentContext: string): Promise<string> => {
  try {
    const ai = getGeminiClient();
    const prompt = `
      Bạn là một thực thể tâm linh, một linh hồn từ quá khứ đang thì thầm vào tai người chơi. 
      Bối cảnh: ${scenarioTitle}. Tình huống hiện tại: ${currentContext}.
      Hãy đưa ra một lời gợi ý ma quái, bí ẩn bằng tiếng Việt (tối đa 2 câu) để giúp người chơi đưa ra lựa chọn lịch sử đúng đắn.
      Giọng văn: Kinh dị, u ám nhưng thông tin phải chính xác về mặt lịch sử.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "Đừng tin vào những gì mắt thấy... Hãy tin vào dòng chảy của nước.";
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini Hint: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini Hint Error:", error?.message || error);
    }
    return "Quá khứ đang gào thét... hãy chọn con đường của sự thật.";
  }
};

export const generateModernStart = async (scenarioId: string): Promise<{ situation: string, transitionTrigger: string }> => {
  try {
    const ai = getGeminiClient();
    const prompt = `
      Hãy tạo một tình huống xuyên không (time travel) logic cho một học sinh dẫn đến kịch bản lịch sử: ${scenarioId}.
      Yêu cầu:
      - Nếu là trận Bạch Đằng: Tình huống liên quan đến nước, cọc gỗ hoặc bảo tàng.
      - Ngôn ngữ: Tiếng Việt.
      - Tông giọng: Huyền bí, rùng rợn (Horror).
      - Trả về định dạng JSON.
      - Situation: Mô tả sự việc kỳ lạ dẫn dắt từ thực tại.
      - TransitionTrigger: Hành động cuối cùng của người chơi để bước qua ranh giới.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            situation: { type: Type.STRING },
            transitionTrigger: { type: Type.STRING }
          },
          required: ["situation", "transitionTrigger"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini Modern Start: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini Modern Start Error:", error?.message || error);
    }
    return {
      situation: "Bạn đang đứng trong một bảo tàng vắng lặng, ánh đèn bỗng chớp tắt liên hồi. Một luồng khí lạnh bao trùm lấy bạn...",
      transitionTrigger: "Bạn chạm tay vào một hiện vật cổ và bị hút vào hư vô."
    };
  }
};

export const generateHistoryNode = async (
  scenario: Scenario,
  history: string[],
  step: number,
  maxSteps: number
): Promise<HistoryNode> => {
  try {
    const ai = getGeminiClient();
    const prompt = `Tạo một cảnh game nhập vai lịch sử u ám cho: ${scenario.title}. Bước: ${step + 1}/${maxSteps}. Lịch sử lựa chọn: ${history.join(" -> ")}.
      Yêu cầu: 
      1. Lời dẫn (narrative) mô tả chi tiết, đậm chất kinh dị (tiếng Việt).
      2. 3 lựa chọn (options) có thông số 'damage' (0-100) và 'msg' phản hồi (tiếng Việt).
      3. 'imagePrompt' mô tả hình ảnh cho AI (tiếng Anh).`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  isCorrect: { type: Type.BOOLEAN },
                  damage: { type: Type.NUMBER },
                  msg: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini History Node: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini History Node Error:", error?.message || error);
    }
    return {
      narrative: "Không gian xung quanh bạn bỗng trở nên mờ ảo. Những tiếng thì thầm từ quá khứ vang vọng, thúc giục bạn phải đưa ra quyết định.",
      imagePrompt: "Mysterious fog in ancient Vietnam, silhouettes of soldiers, dark cinematic atmosphere",
      options: [
        { text: "Tiến lên phía trước", isCorrect: true, damage: 0, msg: "Bạn thận trọng tiến bước." },
        { text: "Lùi lại quan sát", isCorrect: false, damage: 10, msg: "Một bóng đen lướt qua khiến bạn giật mình." },
        { text: "Hỏi thăm người xung quanh", isCorrect: false, damage: 5, msg: "Không ai trả lời, chỉ có tiếng gió rít." }
      ]
    };
  }
};

export const generateSceneImage = async (prompt: string): Promise<string> => {
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: `Horror Visual Novel style, dark, mysterious, cinematic lighting, ancient Vietnam atmosphere: ${prompt}` }] },
      config: { imageConfig: { aspectRatio: "16:9" } }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini Image: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini Image Error:", error?.message || error);
    }
  }
  return `https://picsum.photos/seed/${encodeURIComponent(prompt.slice(0, 20))}/1280/720?blur=2`;
};

export const generateCertificateImage = async (userName: string, scenarioTitle: string): Promise<string> => {
  try {
    const ai = getGeminiClient();
    const prompt = `Một bức Sắc Phong (Decree) cổ kính của triều đình Việt Nam, ghi danh anh hùng ${userName} đã bảo vệ ${scenarioTitle}. Viền rồng phượng, màu vàng đồng rực rỡ trên nền giấy xuyến chỉ u ám.`;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "16:9" } }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
  } catch (error) {
    console.error("Gemini Certificate Error:", error);
  }
  return "https://picsum.photos/seed/certificate/1280/720?sepia=1";
};

export const generateHistoryAudio = async (text: string): Promise<string> => {
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Giọng đọc hào hùng, uy nghiêm, vang vọng từ quá khứ: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini Audio: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini Audio Error:", error?.message || error);
    }
    return "";
  }
};

export const generateFinalSongLyrics = async (scenario: string, choices: string[]): Promise<any> => {
  try {
    const ai = getGeminiClient();
    const prompt = `Viết một bài tế văn hoặc sử ca hào hùng (thơ 4 chữ hoặc lục bát) kỷ niệm chiến thắng tại ${scenario}. Dựa trên các hành động: ${choices.join(", ")}. Ngôn ngữ tiếng Việt cổ kính.`;
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            lyrics: { type: Type.STRING }
          }
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    if (error?.status === 'RESOURCE_EXHAUSTED' || error?.code === 429) {
      console.warn("Gemini Lyrics: Quota exhausted, using fallback.");
    } else {
      console.error("Gemini Lyrics Error:", error?.message || error);
    }
    return { title: "Sử Ca Vang Vọng", lyrics: "Lịch sử ghi dấu ngàn thu\nHào khí dân tộc vươn cao..." };
  }
};
