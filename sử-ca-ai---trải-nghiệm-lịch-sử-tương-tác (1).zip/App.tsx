
import React, { useState } from 'react';
import { GameState, Scenario } from './types';
import LandingPage from './components/LandingPage';
import ScenarioSelector from './components/ScenarioSelector';
import ModernStart from './components/ModernStart';
import TransitionScreen from './components/TransitionScreen';
import GameEngine from './components/GameEngine';
import SongResult from './components/SongResult';
import Photobooth from './components/Photobooth';
import { SCENARIOS } from './constants';

const App: React.FC = () => {
  const [state, setState] = useState<GameState>(GameState.LANDING);
  const [studentName, setStudentName] = useState<string>("");
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);
  const [modernSituation, setModernSituation] = useState<{situation: string, trigger: string} | null>(null);
  const [gameOutcome, setGameOutcome] = useState<{status: 'SUCCESS' | 'FAILED', songData?: any, health: number} | null>(null);

  const handleLandingSubmit = (name: string) => {
    setStudentName(name);
    setState(GameState.SELECT_SCENARIO);
  };

  const handleScenarioSelect = (scenario: Scenario) => {
    setSelectedScenario(scenario);
    if (scenario.id === 'ho-chi-minh-1975') {
      setState(GameState.PLAYING);
    } else {
      setState(GameState.MODERN_INTRO);
    }
  };
  
  const handleTimeTravelTrigger = (situation: string, trigger: string) => {
    setModernSituation({ situation, trigger });
    setState(GameState.TRANSITION);
    setTimeout(() => setState(GameState.PLAYING), 3500);
  };

  const finishGame = (status: 'SUCCESS' | 'FAILED', songData: any, health: number) => {
    setGameOutcome({ status, songData, health });
    setState(GameState.RESULT);
  };

  const reset = () => {
    setState(GameState.LANDING);
    setSelectedScenario(null);
    setModernSituation(null);
    setGameOutcome(null);
  };

  return (
    <div className="min-h-screen w-full flex flex-col bg-[#050505] text-white overflow-x-hidden">
      <main className="flex-1 flex flex-col relative">
        {state === GameState.LANDING && (
          <LandingPage onStart={handleLandingSubmit} />
        )}
        
        {state === GameState.SELECT_SCENARIO && (
          <ScenarioSelector 
            scenarios={SCENARIOS} 
            onSelect={handleScenarioSelect} 
            onBack={() => setState(GameState.LANDING)} 
          />
        )}

        {state === GameState.MODERN_INTRO && selectedScenario && (
          <ModernStart 
            targetScenario={selectedScenario}
            onTravel={handleTimeTravelTrigger} 
            onBack={() => setState(GameState.SELECT_SCENARIO)} 
          />
        )}

        {state === GameState.TRANSITION && selectedScenario && (
          <TransitionScreen scenario={selectedScenario} trigger={modernSituation?.trigger || ""} />
        )}

        {state === GameState.PLAYING && selectedScenario && (
          <GameEngine 
            scenario={selectedScenario} 
            studentName={studentName}
            onFinish={finishGame} 
            onQuit={reset}
          />
        )}

        {state === GameState.RESULT && gameOutcome && (
          <SongResult 
            userName={studentName}
            song={gameOutcome.songData}
            scenario={selectedScenario!} 
            status={gameOutcome.status}
            finalHealth={gameOutcome.health}
            onRestart={reset}
            onGoToPhotobooth={() => setState(GameState.PHOTOBOOTH)}
          />
        )}

        {state === GameState.PHOTOBOOTH && selectedScenario && (
          <Photobooth 
            scenario={selectedScenario} 
            userName={studentName} 
            onBack={() => setState(GameState.RESULT)} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
