
export enum GameState {
  LANDING = 'LANDING',
  SELECT_SCENARIO = 'SELECT_SCENARIO',
  MODERN_INTRO = 'MODERN_INTRO',
  TRANSITION = 'TRANSITION',
  PLAYING = 'PLAYING',
  RESULT = 'RESULT',
  PHOTOBOOTH = 'PHOTOBOOTH'
}

export interface Scenario {
  id: string;
  title: string;
  era: string;
  description: string;
  imagePrompt: string;
  facts: string[];
}

export interface HorrorChoice {
  text: string;
  next: string;
  damage: number;
  msg?: string;
  condition?: string;
}

export interface HorrorStage {
  text: string;
  imagePrompt: string;
  videoUrl?: string;
  choices: HorrorChoice[];
  inventoryAdd?: string;
}

export interface UserChoice {
  nodeId: string;
  choiceText: string;
  isCorrect: boolean;
  damageTaken: number;
}

export interface HistoryNode {
  narrative: string;
  imagePrompt: string;
  options: {
    text: string;
    isCorrect: boolean;
    damage: number;
    msg: string;
  }[];
}
